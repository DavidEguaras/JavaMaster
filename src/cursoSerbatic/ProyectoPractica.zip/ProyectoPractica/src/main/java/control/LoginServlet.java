package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	/*
	 * En el constructor hay que crear un new usarioVO y usuarioDAO y declararlos antes en la clase
	 * En el post: 
	 * 		-Declarar: pagina, user, pass, boolean validarNombre, boolean validarPass
	 * 		-Dentro de un tryCatch: 
	 * 			-Hacemos validaciones, si son validas, le pedimos al DAO que haga un login
	 * 			-Con el usuario atributo que tiene la clase (declarado en el constructor):
	 * 				+Obtenemos el usuario del la base de datos mediante el DAO
	 * 				+Esteblecemos un atributo de la sesion, usuario con el objeto usuario que acabamos de obtener
	 * 				+Traza para exito
	 * 				+Establecemos que pagina sea home (o la pagina a que queremos redirigir)
	 * */
	
	

    /**
     * Default constructor.
     */
    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
