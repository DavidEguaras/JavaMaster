package usuario.control;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import bd.Conexion;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LoginServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Obtener los parámetros de username y password del formulario
		String username = request.getParameter("username");
		String password = request.getParameter("password"); // Aquí el nombre debe ser "password"

		// Llamar al método doLogin para verificar las credenciales
		boolean isLoginSuccessful = doLogin(username, password);

		if (isLoginSuccessful) {
			// Si el login es exitoso, pasar el nombre de usuario a la página welcome.jsp
			request.setAttribute("username", username);
			RequestDispatcher dispatcher = request.getRequestDispatcher("welcome.jsp");
			dispatcher.forward(request, response);
		} else {
			// Si el login falla, redirigir al usuario a la página de login con un mensaje de error
			request.setAttribute("errorMessage", "Invalid username or password. Please try again.");
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); // Cambia esto si usas otra página
			dispatcher.forward(request, response);
		}
	}
	
	protected boolean doLogin(String username, String password) {
		boolean login = false;
		Connection conexion = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;

		try {
			// Obtener conexión a la base de datos
			conexion = Conexion.getConexion();

			if (conexion != null) {
				// Consulta SQL para verificar el nombre de usuario y la contraseña
				String sql = "SELECT * FROM usuarios WHERE nombre=? AND clave=?";
				statement = conexion.prepareStatement(sql);
				statement.setString(1, username);
				statement.setString(2, password);

				// Ejecutar la consulta
				resultSet = statement.executeQuery();

				// Si el resultado tiene al menos una fila, el login es exitoso
				if (resultSet.next()) {
					login = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace(); // Manejo de errores de base de datos
		} finally {
			// Cerrar los recursos
			try {
				if (resultSet != null) resultSet.close();
				if (statement != null) statement.close();
				if (conexion != null) conexion.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return login;
	}
}
