package usuario.model;

public class Usuario {
	
}
