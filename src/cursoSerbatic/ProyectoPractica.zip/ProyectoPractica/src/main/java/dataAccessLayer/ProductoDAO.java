package dataAccessLayer;

import java.sql.*;
import java.util.ArrayList;

import model.ProductoVO;

public class ProductoDAO {

    private Connection conexion;

    public ProductoDAO() {
        // Obtener la conexión a la base de datos
        this.conexion = Conexion.getConexion();
    }

    // Método para obtener todos los productos
    public ArrayList<ProductoVO> listarProductos() {
        ArrayList<ProductoVO> lista = new ArrayList<ProductoVO>();
        String sql = "SELECT * FROM productos";

        try (Statement statement = conexion.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            while (rs.next()) {
                ProductoVO producto = new ProductoVO(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getString("img_ruta"),
                        rs.getDouble("precio"),
                        rs.getInt("cantidad")
                );
                lista.add(producto);
            }

            // Añadir información de depuración
            System.out.println("Productos encontrados: " + lista.size()); // Muestra cuántos productos se encontraron

        } catch (SQLException e) {
            System.out.println("Error al listar productos: " + e.getMessage());
            e.printStackTrace(); // Imprime la traza completa del error
        }

        return lista;
    }


    // Método para insertar un producto
    public boolean insertarProducto(ProductoVO producto) {
        String sql = "INSERT INTO productos (nombre, descripcion, img_ruta, precio, cantidad) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getDescripcion());
            ps.setString(3, producto.getImg_ruta());
            ps.setDouble(4, producto.getPrecio());
            ps.setInt(5, producto.getCantidad());

            int filasInsertadas = ps.executeUpdate();
            return filasInsertadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al insertar producto: " + e.getMessage());
            return false;
        }
    }

    // Método para actualizar un producto
    public boolean actualizarProducto(ProductoVO producto) {
        String sql = "UPDATE productos SET nombre = ?, descripcion = ?, img_ruta = ?, precio = ?, cantidad = ? WHERE id = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, producto.getNombre());
            ps.setString(2, producto.getDescripcion());
            ps.setString(3, producto.getImg_ruta());
            ps.setDouble(4, producto.getPrecio());
            ps.setInt(5, producto.getCantidad());
            ps.setInt(6, producto.getId());

            int filasActualizadas = ps.executeUpdate();
            return filasActualizadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    // Método para eliminar un producto por su ID
    public boolean eliminarProducto(int id) {
        String sql = "DELETE FROM productos WHERE id = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, id);

            int filasEliminadas = ps.executeUpdate();
            return filasEliminadas > 0;

        } catch (SQLException e) {
            System.out.println("Error al eliminar producto: " + e.getMessage());
            return false;
        }
    }

    // Método para obtener un producto por su ID
    public ProductoVO obtenerProductoPorId(int id) {
        ProductoVO producto = null;
        String sql = "SELECT * FROM productos WHERE id = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                producto = new ProductoVO(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getString("img_ruta"),
                        rs.getDouble("precio"),
                        rs.getInt("cantidad")
                );
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener producto por ID: " + e.getMessage());
        }
        return producto;
    }
}
