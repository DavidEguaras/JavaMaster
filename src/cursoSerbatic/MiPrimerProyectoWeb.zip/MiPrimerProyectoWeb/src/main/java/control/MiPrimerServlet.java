package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MiPrimerServlet
 */
@WebServlet({"/MiPrimerServlet", "/primero"})
public class MiPrimerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public MiPrimerServlet() {
        super();
    }
    /**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.getRequestDispatcher("resultado.jsp").forward(request, response);
	}

    // Procesamos el formulario con POST
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String operador1String = request.getParameter("operador1");
        String operador2String = request.getParameter("operador2");
        
        int operador1Int = 0;
        int operador2Int = 0;

        
        try {
            if (operador1String != null && !operador1String.isEmpty()) {
                operador1Int = Integer.parseInt(operador1String);
            }
            if (operador2String != null && !operador2String.isEmpty()) {
                operador2Int = Integer.parseInt(operador2String);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace(); 
        }
        
        
        // Añadimos el parámetro a los atributos del request
        request.setAttribute("resultado", operador1Int + operador2Int);
        // Reenviamos a la página JSP para mostrar el resultado
        request.getRequestDispatcher("resultado.jsp").forward(request, response);
    }
}

