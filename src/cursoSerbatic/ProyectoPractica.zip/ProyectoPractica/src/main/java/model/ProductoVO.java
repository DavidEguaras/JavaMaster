package model;



public class ProductoVO {
    private int id;
    private String nombre;
    private String descripcion;
    private String img_ruta;
    private double precio;
    private int cantidad;

    // Constructor
    public ProductoVO(int id, String nombre, String descripcion, String img_ruta, double precio, int cantidad) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.img_ruta = img_ruta;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getImg_ruta() {
        return img_ruta;
    }

    public void setImg_ruta(String img_ruta) {
        this.img_ruta = img_ruta;
    }
    
    public double getPrecio() {
        return precio;
    }
    
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }
    
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
