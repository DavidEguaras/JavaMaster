package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAO.UsuarioDAO;
import model.UsuarioVO;

@WebServlet("/RegistroServlet")
public class RegistroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    private UsuarioDAO usuarioDAO;

    public RegistroServlet() {
        super();
        usuarioDAO = new UsuarioDAO();
    }

	// Procesamos las peticiones POST (registro)
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String user = request.getParameter("usuario");
        String email = request.getParameter("email");
        String pass = request.getParameter("contraseña");
        String pagina = "index.jsp";

        try {
            if (user != null && email != null && pass != null && 
                !user.isEmpty() && !email.isEmpty() && !pass.isEmpty()) {
                
                UsuarioVO nuevoUsuario = new UsuarioVO(0, user, email);

                boolean registroExitoso = usuarioDAO.insertarUsuario(nuevoUsuario);

                if (registroExitoso) {
                    pagina = "home.jsp";
                } else {
                    pagina = "index.jsp?error=1";
                }
            } else {
                pagina = "index.jsp?error=2";
            }
        } catch (Exception e) {
            e.printStackTrace();
            pagina = "index.jsp?error=3";
        }
        
        response.sendRedirect(pagina);
	}
}
