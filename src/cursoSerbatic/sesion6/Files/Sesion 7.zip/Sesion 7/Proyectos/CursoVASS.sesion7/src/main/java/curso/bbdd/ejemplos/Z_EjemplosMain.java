/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package curso.bbdd.ejemplos;


/**
 *
 * @author Javi
 */



public class Z_EjemplosMain {
	
    public static void main(String[] args)  {
    	
      //  A_EjemploStatement a = new A_EjemploStatement();
     //     B_EjemploResultSet b = new B_EjemploResultSet();
      //  C_EjemploPreparedStatement c = new C_EjemploPreparedStatement();
  //      D_EjemploResultSetMetaData d = new D_EjemploResultSetMetaData();
         // E_EjemploCallableStatement e = new E_EjemploCallableStatement();
  //      F_EjemploProcesamientoBatch f = new F_EjemploProcesamientoBatch();
   //     G_EjemploRowSet g = new G_EjemploRowSet();
        H_EjemploRowSetconRowSetListener h = new H_EjemploRowSetconRowSetListener();
 //      I_ConnectionPool i = new I_ConnectionPool();
 //      i.ejecutar();

    }

}
