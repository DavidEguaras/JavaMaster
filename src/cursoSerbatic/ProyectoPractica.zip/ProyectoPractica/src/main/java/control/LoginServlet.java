package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import DAO.UsuarioDAO;
import model.UsuarioVO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    private UsuarioDAO usuarioDAO;
    private UsuarioVO usuario;

    public LoginServlet() {
        super();
        usuarioDAO = new UsuarioDAO();
    }

	// Procesamos las peticiones POST (inicio de sesión)
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pagina = "index.jsp";
        String user = request.getParameter("usuario");
        String pass = request.getParameter("contraseña");
        boolean validarNombre = false;
        boolean validarPass = false;

        try {
            if (user != null && !user.isEmpty()) {
                validarNombre = true;
            }
            if (pass != null && !pass.isEmpty()) {
                validarPass = true;
            }

            if (validarNombre && validarPass) {
                boolean loginExitoso = usuarioDAO.doLogin(user, pass);

                if (loginExitoso) {
                    usuario = usuarioDAO.getUsuario(user);
                    HttpSession session = request.getSession();
                    session.setAttribute("usuario", usuario);
                    pagina = "home.jsp";
                } else {
                    pagina = "index.jsp?error=1";
                }
            } else {
                pagina = "index.jsp?error=2";
            }
        } catch (Exception e) {
            e.printStackTrace();
            pagina = "index.jsp?error=3";
        }
        
        response.sendRedirect(pagina);
	}
}
