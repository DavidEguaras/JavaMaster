package control.entidades.producto;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dataAccessLayer.ProductoDAO;
import model.ProductoVO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Servlet implementation class ProductoServlet
 */
@WebServlet("")
public class CatalogoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public CatalogoServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener la lista de productos del DAO
		ProductoDAO productoDAO = new ProductoDAO();
		ArrayList<ProductoVO> listaProductos = productoDAO.listarProductos();

		// Guardar la lista de productos como un atributo en el request
		request.setAttribute("listaProductos", listaProductos);

		// Verificar si el carrito de compras está en la sesión, si no, inicializarlo
		if (request.getSession().getAttribute("carrito") == null) {
		    request.getSession().setAttribute("carrito", new HashMap<Integer, ProductoVO>());
		}

		
		request.getRequestDispatcher("home.jsp").forward(request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Llamar al método doGet para manejar las solicitudes POST como GET
        doGet(request, response);
    }
    
    
}
