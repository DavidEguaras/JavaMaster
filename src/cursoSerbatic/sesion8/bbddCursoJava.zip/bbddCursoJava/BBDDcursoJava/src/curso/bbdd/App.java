package curso.bbdd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import curso.bbdd.controllers.ControlAlumno;
import curso.bbdd.daos.AlumnoDAO;
import curso.bbdd.models.Alumn;

public class App {

	public static void main(String[] args) throws SQLException, IOException {
		// TODO Auto-generated method stub
		
			/*opciones menu: 
			 * Introduzca cualquiera de las opciones del menu
			 *1- Crear ficheros con prioridad
			 *2- Hilo demonio contar lineas
			 *3- Hilo de control Inserciones
			 *4- Bloquear metodo ecritura
			 *5- Desbloquear metodo escritura
			 *0- Salir*/	
		
		CrearTresFicherosConPrioridad();
		
	}
	
	
	
	public static void CrearTresFicherosConPrioridad() {
		Thread hilo1 = new Thread(new CrearFichero("src/fichero1.txt"));
		Thread hilo2 = new Thread(new CrearFichero("src/fichero2.txt"));
		Thread hilo3 = new Thread(new CrearFichero("src/fichero3.txt"));
		
		
		hilo1.setPriority(Thread.MAX_PRIORITY);	
		hilo2.setPriority(Thread.NORM_PRIORITY);
		hilo3.setPriority(Thread.MIN_PRIORITY);
		
		hilo1.start();
		hilo2.start();
		hilo3.start();
	}
	
	static class CrearFichero implements Runnable {
        private String nombreFichero;	

        public CrearFichero(String nombreFichero) {
            this.nombreFichero = nombreFichero;
        }

        @Override
        public void run() {
            // Aquí simulamos la creación de un fichero
            System.out.println("Creando " + nombreFichero);
        }
    }
	
	public static void BorrarTresFicheros() {
        String[] nombresFicheros = {
            "src/fichero1.txt",
            "src/fichero2.txt",
            "src/fichero3.txt"
        };

        for (String nombreFichero : nombresFicheros) {
            File fichero = new File(nombreFichero);
            if (fichero.delete()) {
                System.out.println("Fichero " + nombreFichero + " eliminado exitosamente.");
            } else {
                System.out.println("No se pudo eliminar el fichero " + nombreFichero);
            }
        }
    }
	
	
	
    }
	


