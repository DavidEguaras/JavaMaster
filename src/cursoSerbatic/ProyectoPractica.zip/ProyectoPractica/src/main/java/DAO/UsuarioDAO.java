package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.UsuarioVO;

public class UsuarioDAO {

	
    // Método para insertar un nuevo usuario en la base de datos
    public boolean insertarUsuario(UsuarioVO usuario) {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String query = "INSERT INTO usuarios (id, nombre, correo) VALUES (?, ?, ?)";
            try {
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setInt(1, usuario.getId());
                stmt.setString(2, usuario.getNombre());
                stmt.setString(3, usuario.getCorreo());
                stmt.executeUpdate();
                con.commit(); // Confirmamos la transacción
                return true;
            } catch (SQLException e) {
                try {
                    con.rollback(); // En caso de error, hacemos rollback
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                e.printStackTrace();
                return false;
            } finally {
                Conexion.desconectar();
            }
        }
        return false;
    }
    

    // Método para consultar todos los usuarios de la base de datos
    public ArrayList<UsuarioVO> consultarUsuarios() {
        ArrayList<UsuarioVO> listaUsuarios = new ArrayList<>();
        Connection con = Conexion.getConexion();
        if (con != null) {
            String query = "SELECT * FROM usuarios";
            try {
                PreparedStatement stmt = con.prepareStatement(query);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String nombre = rs.getString("nombre");
                    String correo = rs.getString("correo");
                    UsuarioVO usuario = new UsuarioVO(id, nombre, correo);
                    listaUsuarios.add(usuario);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                Conexion.desconectar();
            }
        }
        return listaUsuarios;
    }

    
    // Método para realizar login (devolver true si el nombre y contraseña coinciden)
    public boolean doLogin(String nombre, String contra) {
        Connection con = Conexion.getConexion();
        if (con != null) {
            String query = "SELECT * FROM usuarios WHERE nombre = ? AND password = ?";
            try {
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, nombre);
                stmt.setString(2, contra);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return true; // El login es exitoso
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                Conexion.desconectar();
            }
        }
        return false;
    }
    

    // Método para obtener un usuario por nombre (similar al login pero devuelve el objeto)
    public UsuarioVO getUsuario(String nombre) {
        Connection con = Conexion.getConexion();
        UsuarioVO usuario = null;
        if (con != null) {
            String query = "SELECT * FROM usuarios WHERE nombre = ?";
            try {
                PreparedStatement stmt = con.prepareStatement(query);
                stmt.setString(1, nombre);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    int id = rs.getInt("id");
                    String correo = rs.getString("correo");
                    usuario = new UsuarioVO(id, nombre, correo);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                Conexion.desconectar();
            }
        }
        return usuario;
    }
}
