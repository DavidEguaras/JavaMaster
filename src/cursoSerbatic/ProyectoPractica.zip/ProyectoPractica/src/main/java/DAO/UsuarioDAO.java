package DAO;

public class UsuarioDAO {
	// insertar usuario
		/*
		 * - Accedemos a la bd mediante una conexion
		 * - Si la bd no es null
		 * 		+insert statement en sql
		 * - Desconectamos la bd 
		 * */
	// consultar usuarios (devolver arrayList)
		/*
		 *  - Accedemos a la bd mediante una conexion
		 *  - Creamos el arrayList que vamos a devolver
		 *  - Si la conexion es exitosa:
		 *  	+ Mientras haya siguiente agregamos a la lista*/
	// doLogin (boolean), parametros nombre y contra
		/*	- Accedemos a la bd mediante una conexion
		 * 	- consulta para que un cliente coincida
		 	*/
	// getUsuario (UsuarioVO)
		/*	- lo mismo que login pero devolviendo el objeto usuario
		 	*/
}
